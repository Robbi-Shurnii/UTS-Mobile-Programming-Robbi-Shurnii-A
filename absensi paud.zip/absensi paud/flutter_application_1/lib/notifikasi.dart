import 'package:flutter/material.dart';

class NotifikasiPage extends StatefulWidget {
  const NotifikasiPage({super.key});

  @override
  State<NotifikasiPage> createState() => _NotifikasiPageState();
}

class _NotifikasiPageState extends State<NotifikasiPage> {
  bool notifikasiAktif = true;

  List<Map<String, String>> notifikasiList = [
    {
      "judul": "Pengingat Absen Pagi",
      "waktu": "07:00 WIB",
      "pesan": "Jangan lupa absen pagi hari ini!"
    },
    {
      "judul": "Pengingat Absen Siang",
      "waktu": "12:00 WIB",
      "pesan": "Sudah waktunya absen siang."
    },
    {
      "judul": "Pengingat Absen Pulang",
      "waktu": "15:00 WIB",
      "pesan": "Jangan lupa absen sebelum pulang!"
    },
  ];

  void editNotifikasi(int index) {
    final judulController =
        TextEditingController(text: notifikasiList[index]["judul"]);
    final waktuController =
        TextEditingController(text: notifikasiList[index]["waktu"]);
    final pesanController =
        TextEditingController(text: notifikasiList[index]["pesan"]);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text(
            "Edit Notifikasi",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          content: SingleChildScrollView(
            child: Column(
              children: [
                TextField(
                  controller: judulController,
                  decoration: const InputDecoration(labelText: "Judul"),
                ),
                TextField(
                  controller: waktuController,
                  decoration: const InputDecoration(labelText: "Waktu"),
                ),
                TextField(
                  controller: pesanController,
                  decoration: const InputDecoration(labelText: "Pesan"),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Batal"),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  notifikasiList[index]["judul"] = judulController.text;
                  notifikasiList[index]["waktu"] = waktuController.text;
                  notifikasiList[index]["pesan"] = pesanController.text;
                });
                Navigator.pop(context);
              },
              child: const Text("Simpan"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 260,
          height: 580,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 12)],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 220,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Judul Header
              const Positioned(
                top: 30,
                left: 85,
                child: Text(
                  "Notifikasi",
                  style: TextStyle(
                    fontFamily: "Open Sans",
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Tombol ON/OFF
              Positioned(
                top: 80,
                left: 45,
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      notifikasiAktif = !notifikasiAktif;
                    });
                  },
                  child: Container(
                    width: 160,
                    height: 40,
                    decoration: BoxDecoration(
                      color: notifikasiAktif
                          ? Colors.green
                          : const Color(0xFFB71C1C),
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: const [
                        BoxShadow(color: Colors.black26, blurRadius: 4)
                      ],
                    ),
                    child: Center(
                      child: Text(
                        notifikasiAktif
                            ? "🔔 Notifikasi ON"
                            : "🔕 Notifikasi OFF",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Daftar Notifikasi
              Positioned(
                top: 130,
                left: 8,
                right: 8,
                bottom: 70,
                child: Container(
                  width: 220,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: !notifikasiAktif
                      ? const Center(
                          child: Text(
                            "Notifikasi dimatikan",
                            style: TextStyle(
                              color: Color(0xFF53B7E8),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(10),
                          itemCount: notifikasiList.length,
                          itemBuilder: (context, index) {
                            final notif = notifikasiList[index];
                            return Container(
                              margin: const EdgeInsets.symmetric(
                                  vertical: 8, horizontal: 6),
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: const [
                                  BoxShadow(
                                      color: Colors.black26,
                                      blurRadius: 6,
                                      offset: Offset(0, 3)),
                                ],
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Icon(Icons.notifications_active,
                                      color: Color(0xFF53B7E8)),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          notif["judul"]!,
                                          style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xFF0365A0),
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          notif["pesan"]!,
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.black87,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          "⏰ ${notif["waktu"]!}",
                                          style: const TextStyle(
                                            fontSize: 11,
                                            color: Colors.grey,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.edit,
                                        size: 20, color: Colors.grey),
                                    onPressed: () => editNotifikasi(index),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
              ),

              // Tombol kembali
              Positioned(
                bottom: 20,
                left: 70,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 110,
                    height: 35,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0365A0),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Center(
                      child: Text(
                        "Kembali",
                        style: TextStyle(
                          fontFamily: "Open Sans",
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}