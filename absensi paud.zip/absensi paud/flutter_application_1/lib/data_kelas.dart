import 'package:flutter/material.dart';

class DataKelasPage extends StatelessWidget {
  const DataKelasPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Daftar kelas beserta batasan usianya
    final List<Map<String, String>> dataKelas = [
      {"nama": "Kelas Besar", "usia": "5 - 6 Tahun"},
      {"nama": "Kelas Kecil", "usia": "3 - 4 Tahun"},
    ];

    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 260,
          height: 580,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 12)],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 220,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Judul header
              const Positioned(
                top: 30,
                left: 80,
                child: Text(
                  "Data Kelas",
                  style: TextStyle(
                    fontFamily: "Open Sans",
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Daftar kelas
              Positioned(
                top: 90,
                left: 8,
                right: 8,
                child: Container(
                  width: 220,
                  height: 420,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: dataKelas.length,
                    itemBuilder: (context, index) {
                      return Container(
                        margin: const EdgeInsets.only(bottom: 16),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: const [
                            BoxShadow(
                              color: Colors.black26,
                              blurRadius: 6,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              dataKelas[index]['nama']!,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF0365A0),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Batas Usia: ${dataKelas[index]['usia']!}",
                              style: const TextStyle(
                                fontSize: 13,
                                color: Colors.black87,
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ),

              // Tombol kembali
              Positioned(
                bottom: 20,
                left: 70,
                child: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    width: 110,
                    height: 35,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0365A0),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Center(
                      child: Text(
                        "Kembali",
                        style: TextStyle(
                          fontFamily: "Open Sans",
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
