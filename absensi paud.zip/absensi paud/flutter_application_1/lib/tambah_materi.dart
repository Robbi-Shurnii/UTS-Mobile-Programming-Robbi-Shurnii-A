import 'package:flutter/material.dart';
import 'daftar_materi.dart';

class TambahMateriPage extends StatefulWidget {
  const TambahMateriPage({super.key});

  @override
  State<TambahMateriPage> createState() => _TambahMateriPageState();
}

class _TambahMateriPageState extends State<TambahMateriPage> {
  final TextEditingController _judulController = TextEditingController();
  final TextEditingController _kegiatanController = TextEditingController();

  void _simpanMateri() {
    final judul = _judulController.text.trim();
    final kegiatan = _kegiatanController.text.trim();

    if (judul.isNotEmpty && kegiatan.isNotEmpty) {
      daftarMateri.add(Materi(judul: judul, kegiatan: kegiatan));
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const DaftarMateriPage()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi semua kolom terlebih dahulu!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 12)],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                  child: const Center(
                    child: Text(
                      "Tambah Materi",
                      style: TextStyle(
                        fontFamily: "Open Sans",
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),

              // Input Judul
              Positioned(
                top: 90,
                left: 8,
                child: _buildInputField(
                  controller: _judulController,
                  hint: "Masukkan Judul Materi",
                ),
              ),

              // Input Kegiatan
              Positioned(
                top: 150,
                left: 8,
                child: _buildInputField(
                  controller: _kegiatanController,
                  hint: "Masukkan Kegiatan",
                ),
              ),

              // Tombol Simpan
              Positioned(
                bottom: 40,
                left: 8,
                child: GestureDetector(
                  onTap: _simpanMateri,
                  child: Container(
                    width: 200,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0365A0),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: const Center(
                      child: Text(
                        "Simpan Materi",
                        style: TextStyle(
                          fontFamily: "Open Sans",
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hint,
  }) {
    return Container(
      width: 200,
      height: 43,
      decoration: BoxDecoration(
        color: const Color(0xFFF7FCFF),
        borderRadius: BorderRadius.circular(35),
      ),
      child: TextField(
        controller: controller,
        textAlign: TextAlign.center,
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: hint,
          hintStyle: const TextStyle(
            color: Color(0xFF53B7E8),
            fontWeight: FontWeight.bold,
            fontSize: 13,
          ),
        ),
        style: const TextStyle(
          color: Color(0xFF53B7E8),
          fontWeight: FontWeight.bold,
          fontSize: 13,
        ),
      ),
    );
  }
}