import 'package:flutter/material.dart';
import 'daftar_siswa.dart';
import 'tambah_siswa.dart';
import 'rekap_absensi.dart';


// Halaman utama Absensi
class AbsensiPage extends StatefulWidget {
  const AbsensiPage({super.key});

  @override
  State<AbsensiPage> createState() => _AbsensiPageState();
}

class _AbsensiPageState extends State<AbsensiPage> {
  DateTime selectedDate = DateTime(2025, 10, 6); // default tanggal

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Color(0xFF53B7E8),
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12),
            ],
          ),
          child: Stack(
            children: [
              // Bagian biru atas
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 80,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Judul Absensi
              const Positioned(
                top: 24,
                left: 28,
                child: Text(
                  'Absensi',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 18,
                  ),
                ),
              ),

              // Tanggal bisa diubah
              Positioned(
                top: 57,
                left: 28,
                child: GestureDetector(
                  onTap: () => _selectDate(context),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.calendar_today,
                          color: Colors.white,
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "${selectedDate.day} / ${selectedDate.month} / ${selectedDate.year}",
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // === Tombol 1: Daftar Siswa ===
              Positioned(
                top: 100,
                left: 8,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const DaftarSiswaPage(),
                      ),
                    );
                  },
                  child: _menuButton('Daftar Siswa'),
                ),
              ),

              // === Tombol 2: Tambah Siswa ===
              Positioned(
                top: 160,
                left: 8,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const TambahSiswaPage(),
                      ),
                    );
                  },
                  child: _menuButton('Tambah Siswa'),
                ),
              ),

              // === Tombol 3: Rekap Absensi ===
              Positioned(
                top: 220,
                left: 8,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const RekapAbsensiPage(),
                      ),
                    );
                  },
                  child: _menuButton('Rekap Absensi'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Widget tombol menu
  Widget _menuButton(String title) {
    return Container(
      width: 200,
      height: 40,
      decoration: BoxDecoration(
        color: const Color(0xFFF7FCFF),
        borderRadius: BorderRadius.circular(35),
      ),
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.only(left: 30),
      child: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 16,
          color: Color(0xFF53B7E8),
        ),
      ),
    );
  }
}