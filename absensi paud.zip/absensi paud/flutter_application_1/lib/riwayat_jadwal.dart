import 'package:flutter/material.dart';

List<Map<String, String>> daftarJadwal = [];

class RiwayatJadwalPage extends StatefulWidget {
  final Map<String, String>? jadwalBaru;

  const RiwayatJadwalPage({super.key, this.jadwalBaru});

  @override
  State<RiwayatJadwalPage> createState() => _RiwayatJadwalPageState();
}

class _RiwayatJadwalPageState extends State<RiwayatJadwalPage> {
  @override
  void initState() {
    super.initState();
    if (widget.jadwalBaru != null) {
      daftarJadwal.add(widget.jadwalBaru!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                  child: const Center(
                    child: Text(
                      'Riwayat Jadwal',
                      style: TextStyle(
                        fontFamily: 'Open Sans',
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),

              // Daftar jadwal
              Positioned(
                top: 80,
                left: 8,
                right: 8,
                bottom: 10,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: daftarJadwal.isEmpty
                      ? const Center(
                          child: Text(
                            "Belum ada jadwal",
                            style: TextStyle(
                              color: Color(0xFF53B7E8),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                      : ListView.builder(
                          itemCount: daftarJadwal.length,
                          itemBuilder: (context, index) {
                            final item = daftarJadwal[index];
                            return ListTile(
                              title: Text(
                                item['kegiatan'] ?? '',
                                style: const TextStyle(
                                  color: Color(0xFF53B7E8),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              subtitle: Text(
                                '${item['tanggal']} | ${item['waktu']}',
                                style: const TextStyle(
                                  color: Colors.black54,
                                  fontSize: 12,
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}