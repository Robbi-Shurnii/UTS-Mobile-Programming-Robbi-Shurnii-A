import 'package:flutter/material.dart';
import 'hadir_alpa_izin_sakit.dart';

class RekapAbsenAlpaPage extends StatelessWidget {
  const RekapAbsenAlpaPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Ambil data siswa yang berstatus Alpa
    final siswaAlpa = absensiData.entries
        .where((e) => e.value == 'Alpa')
        .map((e) => e.key)
        .toList();

    return Scaffold(
      backgroundColor: const Color(0xFF53B7E8),
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 12)],
          ),
          child: Stack(
            children: [
              // Header biru
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 60,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                  child: const Center(
                    child: Text(
                      "Daftar Alpa",
                      style: TextStyle(
                        fontFamily: 'Open Sans',
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),

              // Tombol kembali
              Positioned(
                top: 80,
                left: 20,
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: const Icon(Icons.arrow_back, color: Colors.white),
                ),
              ),

              // Daftar siswa alpa
              Positioned(
                top: 110,
                left: 8,
                right: 8,
                bottom: 10,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: siswaAlpa.isEmpty
                      ? const Center(
                          child: Text(
                            "Belum ada siswa alpa",
                            style: TextStyle(
                              color: Color(0xFF53B7E8),
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        )
                      : ListView.builder(
                          itemCount: siswaAlpa.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 6.0),
                              child: Row(
                                children: [
                                  const Icon(Icons.person_off,
                                      color: Color(0xFF53B7E8), size: 18),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      siswaAlpa[index],
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF53B7E8),
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}