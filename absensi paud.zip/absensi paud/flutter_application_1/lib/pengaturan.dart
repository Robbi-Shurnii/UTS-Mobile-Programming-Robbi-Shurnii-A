import 'package:flutter/material.dart';
import 'package:flutter_application_1/notifikasi.dart';
import 'profil_sekolah.dart'; // import halaman profil sekolah
import 'profil_guru.dart';
import 'data_kelas.dart';
import 'notifikasi.dart';
import 'keluar.dart';

class PengaturanPage extends StatelessWidget {
  const PengaturanPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [
              BoxShadow(color: Colors.black38, blurRadius: 12),
            ],
          ),
          child: Stack(
            children: [
              // Header biru
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Judul
              const Positioned(
                top: 30,
                left: 65,
                child: Text(
                  "Pengaturan",
                  style: TextStyle(
                    fontFamily: "Open Sans",
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Tombol Profil Sekolah
              _menuButton(
                top: 83,
                label: "Profil Sekolah",
                iconPath: "image/profilsekolah.png",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ProfilSekolahPage(),
                    ),
                  );
                },
              ),

              // Tombol lainnya (belum dikaitkan)
              _menuButton(
                top: 143,
                label: "Profil Guru",
                iconPath: "image/profilguru.png",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const ProfilGuruPage(),
                    ),
                  );
                },
              ),
              _menuButton(
                top: 203,
                label: "Data Kelas",
                iconPath: "image/datakelas.png",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const DataKelasPage(),
                    ),
                  );
                },
              ),
              _menuButton(
                top: 263,
                label: "Notifikasi",
                iconPath: "image/notifikasi.jpg",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const NotifikasiPage(),
                    ),
                  );
                },
              ),
              _menuButton(
                top: 323,
                label: "Keluar",
                iconPath: "image/keluar.png",
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const KeluarPage(),
                    ),
                  );
                },
              ),

            ],
          ),
        ),
      ),
    );
  }

  // Widget tombol menu
  static Widget _menuButton({
    required double top,
    required String label,
    required String iconPath,
    required VoidCallback onTap,
  }) {
    return Positioned(
      top: top,
      left: 8,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 200,
          height: 43,
          decoration: BoxDecoration(
            color: const Color(0xFFF7FCFF),
            borderRadius: BorderRadius.circular(35),
          ),
          child: Row(
            children: [
              const SizedBox(width: 12),
              Image.asset(
                iconPath,
                width: 25,
                height: 25,
                fit: BoxFit.cover,
              ),
              const SizedBox(width: 15),
              Text(
                label,
                style: const TextStyle(
                  fontFamily: "Open Sans",
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF53B7E8),
                  fontSize: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}