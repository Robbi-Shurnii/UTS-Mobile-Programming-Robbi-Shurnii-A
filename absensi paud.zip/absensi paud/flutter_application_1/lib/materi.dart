import 'package:flutter/material.dart';
import 'daftar_materi.dart';
import 'tambah_materi.dart';

class MateriPage extends StatelessWidget {
  const MateriPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [
              BoxShadow(color: Colors.black38, blurRadius: 12),
            ],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),
              const Positioned(
                top: 30,
                left: 36,
                child: Text(
                  "Materi Pembelajaran",
                  style: TextStyle(
                    fontFamily: "Open Sans",
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Tombol Daftar Materi
              Positioned(
                top: 83,
                left: 8,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const DaftarMateriPage()),
                    );
                  },
                  child: Container(
                    width: 200,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: const Center(
                      child: Text(
                        "Daftar Materi",
                        style: TextStyle(
                          fontFamily: "Open Sans",
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF53B7E8),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Tombol Tambah Materi
              Positioned(
                top: 143,
                left: 8,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const TambahMateriPage()),
                    );
                  },
                  child: Container(
                    width: 200,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: const Center(
                      child: Text(
                        "Tambah Materi",
                        style: TextStyle(
                          fontFamily: "Open Sans",
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF53B7E8),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}