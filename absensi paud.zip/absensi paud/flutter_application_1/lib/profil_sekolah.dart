import 'package:flutter/material.dart';

class ProfilSekolahPage extends StatelessWidget {
  const ProfilSekolahPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [
              BoxShadow(color: Colors.black38, blurRadius: 12),
            ],
          ),
          child: Stack(
            children: [
              // Header biru tua
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Judul di header
              const Positioned(
                top: 30,
                left: 60,
                child: Text(
                  "Profil Sekolah",
                  style: TextStyle(
                    fontFamily: "Open Sans",
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Isi profil sekolah
              Positioned(
                top: 90,
                left: 8,
                right: 8,
                child: Container(
                  width: 200,
                  height: 330,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: const Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Center(
                          child: Icon(
                            Icons.school_rounded,
                            color: Color(0xFF53B7E8),
                            size: 50,
                          ),
                        ),
                        SizedBox(height: 10),
                        Center(
                          child: Text(
                            "Paud Lestari IV",
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF0365A0),
                            ),
                          ),
                        ),
                        SizedBox(height: 16),
                        Text(
                          "📍 Alamat:",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF0365A0),
                          ),
                        ),
                        Text(
                          "Jl. Keramik Gg. Pejuang, Karangtalun",
                          style: TextStyle(color: Colors.black87),
                        ),
                        SizedBox(height: 10),
                        Text(
                          "👩 Kepala Sekolah:",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF0365A0),
                          ),
                        ),
                        Text(
                          "Ibu Wartinah",
                          style: TextStyle(color: Colors.black87),
                        ),
                        SizedBox(height: 10),
                        Text(
                          "📅 Tahun Berdiri:",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF0365A0),
                          ),
                        ),
                        Text(
                          "2008",
                          style: TextStyle(color: Colors.black87),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Tombol kembali
              Positioned(
                bottom: 20,
                left: 60,
                child: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    width: 100,
                    height: 35,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0365A0),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Center(
                      child: Text(
                        "Kembali",
                        style: TextStyle(
                          fontFamily: "Open Sans",
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}