import 'package:flutter/material.dart';

class TambahSiswaPage extends StatefulWidget {
  const TambahSiswaPage({super.key});

  @override
  State<TambahSiswaPage> createState() => _TambahSiswaPageState();
}

class _TambahSiswaPageState extends State<TambahSiswaPage> {
  final TextEditingController namaController = TextEditingController();
  final TextEditingController ttlController = TextEditingController();
  final TextEditingController alamatController = TextEditingController();
  final TextEditingController ortuController = TextEditingController();

  String? jenisKelamin;

  void simpanData() {
    if (namaController.text.isEmpty ||
        jenisKelamin == null ||
        ttlController.text.isEmpty ||
        alamatController.text.isEmpty ||
        ortuController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Harap isi semua data siswa")),
      );
      return;
    }

    final siswaBaru = {
      'nama': namaController.text,
      'jenisKelamin': jenisKelamin,
      'ttl': ttlController.text,
      'alamat': alamatController.text,
      'orangTua': ortuController.text,
    };

    Navigator.pop(context, siswaBaru); // kirim data ke halaman sebelumnya
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF53b7e8),
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53b7e8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [
              BoxShadow(
                color: Colors.black45,
                blurRadius: 12,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                  child: const Center(
                    child: Text(
                      "Tambah Siswa",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),

              // Form isi
              Positioned(
                top: 90,
                left: 20,
                right: 20,
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Nama lengkap
                      const Text("Nama Lengkap",
                          style: TextStyle(color: Colors.white, fontSize: 11)),
                      TextField(
                        controller: namaController,
                        style: const TextStyle(fontSize: 12, color: Colors.white),
                        decoration: const InputDecoration(
                          isDense: true,
                          hintText: "Masukkan nama lengkap",
                          hintStyle: TextStyle(color: Colors.white70),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white54)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Tempat tanggal lahir
                      const Text("Tempat, Tanggal Lahir",
                          style: TextStyle(color: Colors.white, fontSize: 11)),
                      TextField(
                        controller: ttlController,
                        style: const TextStyle(fontSize: 12, color: Colors.white),
                        decoration: const InputDecoration(
                          isDense: true,
                          hintText: "Contoh: Surabaya, 1 Januari 2019",
                          hintStyle: TextStyle(color: Colors.white70),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white54)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Alamat
                      const Text("Alamat",
                          style: TextStyle(color: Colors.white, fontSize: 11)),
                      TextField(
                        controller: alamatController,
                        style: const TextStyle(fontSize: 12, color: Colors.white),
                        decoration: const InputDecoration(
                          isDense: true,
                          hintText: "Masukkan alamat siswa",
                          hintStyle: TextStyle(color: Colors.white70),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white54)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Nama orang tua
                      const Text("Nama Orang Tua",
                          style: TextStyle(color: Colors.white, fontSize: 11)),
                      TextField(
                        controller: ortuController,
                        style: const TextStyle(fontSize: 12, color: Colors.white),
                        decoration: const InputDecoration(
                          isDense: true,
                          hintText: "Masukkan nama orang tua",
                          hintStyle: TextStyle(color: Colors.white70),
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white54)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // Jenis kelamin
                      const Text("Jenis Kelamin",
                          style: TextStyle(color: Colors.white, fontSize: 11)),
                      DropdownButtonFormField<String>(
                        value: jenisKelamin,
                        dropdownColor: const Color(0xFF0365A0),
                        decoration: const InputDecoration(
                          enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white54)),
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white)),
                        ),
                        style:
                            const TextStyle(color: Colors.white, fontSize: 12),
                        hint: const Text("Pilih Jenis Kelamin",
                            style: TextStyle(color: Colors.white70)),
                        items: const [
                          DropdownMenuItem(
                              value: "Laki-laki", child: Text("Laki-laki")),
                          DropdownMenuItem(
                              value: "Perempuan", child: Text("Perempuan")),
                        ],
                        onChanged: (val) {
                          setState(() {
                            jenisKelamin = val;
                          });
                        },
                      ),
                      const SizedBox(height: 24),

                      // Tombol simpan
                      GestureDetector(
                        onTap: simpanData,
                        child: Container(
                          height: 35,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(35),
                          ),
                          child: const Center(
                            child: Text(
                              "SIMPAN",
                              style: TextStyle(
                                color: Color(0xFF53b7e8),
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}