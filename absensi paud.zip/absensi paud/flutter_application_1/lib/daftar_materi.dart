import 'package:flutter/material.dart';
import 'detail_materi.dart';

// Struktur data materi: judul + kegiatan
class Materi {
  final String judul;
  final String kegiatan;

  Materi({required this.judul, required this.kegiatan});
}

// List global untuk menyimpan data
List<Materi> daftarMateri = [];

class DaftarMateriPage extends StatefulWidget {
  const DaftarMateriPage({super.key});

  @override
  State<DaftarMateriPage> createState() => _DaftarMateriPageState();
}

class _DaftarMateriPageState extends State<DaftarMateriPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 12)],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                  child: const Center(
                    child: Text(
                      "Daftar Materi",
                      style: TextStyle(
                        fontFamily: "Open Sans",
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),

              // List Materi
              Positioned(
                top: 80,
                left: 8,
                right: 8,
                bottom: 10,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: daftarMateri.isEmpty
                      ? const Center(
                          child: Text(
                            "Belum ada materi",
                            style: TextStyle(
                              color: Color(0xFF53B7E8),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        )
                      : ListView.builder(
                          itemCount: daftarMateri.length,
                          itemBuilder: (context, index) {
                            final materi = daftarMateri[index];
                            return ListTile(
                              title: Text(
                                materi.judul,
                                style: const TextStyle(
                                  color: Color(0xFF53B7E8),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => DetailMateriPage(
                                      judul: materi.judul,
                                      kegiatan: materi.kegiatan,
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}