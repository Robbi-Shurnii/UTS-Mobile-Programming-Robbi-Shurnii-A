import 'package:flutter/material.dart';
import 'login_page.dart'; // pastikan file login_page.dart ada

class SignupPage extends StatelessWidget {
  const SignupPage({super.key});

  @override
  Widget build(BuildContext context) {
    final usernameController = TextEditingController();
    final passwordController = TextEditingController();
    final confirmPasswordController = TextEditingController();

    return Scaffold(
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('assets/image/wallpaper.jpg'),
              fit: BoxFit.cover,
              alignment: Alignment.center,
            ),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 12),
            ],
          ),
          child: Stack(
            children: [
              // Background Rectangle
              Positioned(
                top: 165,
                left: 0,
                child: Container(
                  width: 300,
                  height: 300,
                  decoration: BoxDecoration(
                    color: const Color(0xFF53B7E8),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(45),
                      topRight: Radius.circular(45),
                    ),
                    border: const Border(
                      top: BorderSide(color: Colors.white, width: 7),
                      left: BorderSide(color: Colors.white, width: 8),
                    ),
                  ),
                ),
              ),

              // Title: Sign Up
              const Positioned(
                top: 190,
                left: 85,
                child: Text(
                  'Sign Up',
                  style: TextStyle(
                    fontFamily: 'Open Sans',
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    fontSize: 20,
                  ),
                ),
              ),

              // Username
              const Positioned(
                top: 235,
                left: 20,
                child: Text(
                  'Username',
                  style: TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
              Positioned(
                top: 250,
                left: 20,
                right: 20,
                child: SizedBox(
                  height: 30,
                  child: TextField(
                    controller: usernameController,
                    style: const TextStyle(fontSize: 12, color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Enter your username',
                      hintStyle:
                          const TextStyle(color: Colors.white70, fontSize: 11),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white54),
                      ),
                    ),
                  ),
                ),
              ),

              // Password
              const Positioned(
                top: 287,
                left: 20,
                child: Text(
                  'Password',
                  style: TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
              Positioned(
                top: 302,
                left: 20,
                right: 20,
                child: SizedBox(
                  height: 30,
                  child: TextField(
                    controller: passwordController,
                    obscureText: true,
                    style: const TextStyle(fontSize: 12, color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Enter your password',
                      hintStyle:
                          const TextStyle(color: Colors.white70, fontSize: 11),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white54),
                      ),
                    ),
                  ),
                ),
              ),

              // Confirm Password
              const Positioned(
                top: 338,
                left: 20,
                child: Text(
                  'Confirm Password',
                  style: TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
              Positioned(
                top: 353,
                left: 20,
                right: 20,
                child: SizedBox(
                  height: 30,
                  child: TextField(
                    controller: confirmPasswordController,
                    obscureText: true,
                    style: const TextStyle(fontSize: 12, color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Confirm your password',
                      hintStyle:
                          const TextStyle(color: Colors.white70, fontSize: 11),
                      filled: true,
                      fillColor: Colors.white.withOpacity(0.2),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: const BorderSide(color: Colors.white54),
                      ),
                    ),
                  ),
                ),
              ),

              // Sign Up Button (klik untuk ke halaman login)
              Positioned(
                top: 395,
                left: 22,
                child: SizedBox(
                  width: 180,
                  height: 35,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF53B7E8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                        side: const BorderSide(color: Colors.white, width: 3),
                      ),
                    ),
                    onPressed: () {
                      // pindah ke halaman login
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const LoginPage(),
                        ),
                      );
                    },
                    child: const Text(
                      'Sign Up',
                      style: TextStyle(
                        fontFamily: 'Open Sans',
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
