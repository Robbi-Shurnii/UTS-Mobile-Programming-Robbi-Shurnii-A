import 'package:flutter/material.dart';
import 'absensi.dart';
import 'jadwal.dart';
import 'materi.dart';
import 'pengaturan.dart';

// ======================
// DASHBOARD PAGE
// ======================
class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Bagian biru atas
              Positioned(
                top: 11,
                left: 7,
                child: Container(
                  width: 202,
                  height: 175,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Tombol Absensi
              Positioned(
                top: 203,
                left: 7,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const AbsensiPage()),
                    );
                  },
                  child: Container(
                    width: 202,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                  ),
                ),
              ),

              // Tombol Jadwal
              Positioned(
                top: 260,
                left: 7,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const JadwalPage()),
                    );
                  },
                  child: Container(
                    width: 202,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                  ),
                ),
              ),

              // Tombol Materi
              Positioned(
                top: 317,
                left: 7,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const MateriPage()),
                    );
                  },
                  child: Container(
                    width: 202,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                  ),
                ),
              ),

              // Tombol Pengaturan
              Positioned(
                top: 374,
                left: 7,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const PengaturanPage()),
                    );
                  },
                  child: Container(
                    width: 202,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                  ),
                ),
              ),

              // Teks Halo
              const Positioned(
                top: 34,
                left: 36,
                child: Text(
                  'Halo, Selamat Datang',
                  style: TextStyle(
                    fontFamily: 'Open Sans',
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
              ),

              // Gambar laki-laki
              Positioned(
                top: 48,
                left: 28,
                child: Image.asset(
                  'image/laki.png',
                  width: 102,
                  height: 138,
                  fit: BoxFit.cover,
                ),
              ),

              // Gambar perempuan
              Positioned(
                top: 52,
                left: 91,
                child: Image.asset(
                  'image/perempuan.png',
                  width: 100,
                  height: 134,
                  fit: BoxFit.cover,
                ),
              ),

              // Label teks menu
              const Positioned(
                top: 215,
                left: 48,
                child: Text(
                  'Absensi',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Color(0xFF53B7E8),
                  ),
                ),
              ),
              const Positioned(
                top: 272,
                left: 48,
                child: Text(
                  'Jadwal',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Color(0xFF53B7E8),
                  ),
                ),
              ),
              const Positioned(
                top: 329,
                left: 48,
                child: Text(
                  'Materi',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Color(0xFF53B7E8),
                  ),
                ),
              ),
              const Positioned(
                top: 386,
                left: 48,
                child: Text(
                  'Pengaturan',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Color(0xFF53B7E8),
                  ),
                ),
              ),

              // Ikon menu
              Positioned(
                top: 210,
                left: 5,
                child: Image.asset(
                  'image/absensi.png',
                  width: 45,
                  height: 25,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 268,
                left: 5,
                child: Image.asset(
                  'image/jadwal.png',
                  width: 45,
                  height: 25,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 326,
                left: 9,
                child: Image.asset(
                  'image/materi.png',
                  width: 35,
                  height: 25,
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                top: 382,
                left: 13,
                child: Image.asset(
                  'image/setting.png',
                  width: 30,
                  height: 25,
                  fit: BoxFit.cover,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}