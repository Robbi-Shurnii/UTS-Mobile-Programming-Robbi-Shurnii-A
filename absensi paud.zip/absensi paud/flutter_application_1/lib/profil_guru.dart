import 'package:flutter/material.dart';

class ProfilGuruPage extends StatelessWidget {
  const ProfilGuruPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Data guru tetap (tidak bisa diubah)
    final List<Map<String, String>> guruList = [
      {"nama": "Ibu Listianti", "jabatan": "Guru Kelas Besar"},
      {"nama": "Ibu Dwi Rumiyatun", "jabatan": "Guru Kelas Kecil"},
    ];

    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 260,
          height: 580,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 12)],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 220,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Judul header
              const Positioned(
                top: 30,
                left: 80,
                child: Text(
                  "Profil Guru",
                  style: TextStyle(
                    fontFamily: "Open Sans",
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Isi profil
              Positioned(
                top: 90,
                left: 8,
                right: 8,
                child: Container(
                  width: 220,
                  height: 420,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        for (int i = 0; i < guruList.length; i++) ...[
                          const Icon(
                            Icons.person_rounded,
                            color: Color(0xFF53B7E8),
                            size: 50,
                          ),
                          Text(
                            "Guru ${i + 1}",
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.black87,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            guruList[i]["nama"]!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF0365A0),
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            guruList[i]["jabatan"]!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 13,
                              color: Colors.black87,
                            ),
                          ),
                          if (i < guruList.length - 1) ...[
                            const SizedBox(height: 15),
                            const Divider(thickness: 1),
                            const SizedBox(height: 15),
                          ],
                        ],
                      ],
                    ),
                  ),
                ),
              ),

              // Tombol kembali
              Positioned(
                bottom: 20,
                left: 70,
                child: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    width: 110,
                    height: 35,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0365A0),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Center(
                      child: Text(
                        "Kembali",
                        style: TextStyle(
                          fontFamily: "Open Sans",
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
