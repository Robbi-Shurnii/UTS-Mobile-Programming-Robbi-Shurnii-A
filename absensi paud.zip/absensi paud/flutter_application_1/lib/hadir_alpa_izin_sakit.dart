import 'package:flutter/material.dart';
import 'rekap_absensi.dart';

// 🔹 Data absensi global untuk rekap
Map<String, String> absensiData = {};

class HadirAlpaIzinSakitPage extends StatefulWidget {
  final String namaSiswa;

  const HadirAlpaIzinSakitPage({super.key, required this.namaSiswa});

  @override
  State<HadirAlpaIzinSakitPage> createState() => _HadirAlpaIzinSakitPageState();
}

class _HadirAlpaIzinSakitPageState extends State<HadirAlpaIzinSakitPage> {
  String? statusTerpilih;

  void _simpanAbsensi() {
    if (statusTerpilih != null) {
      absensiData[widget.namaSiswa] = statusTerpilih!;
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF53B7E8),
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [
              BoxShadow(color: Colors.black38, blurRadius: 12),
            ],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              // Nama Siswa
              Positioned(
                top: 30,
                left: 40,
                child: Text(
                  widget.namaSiswa,
                  style: const TextStyle(
                    fontFamily: 'Open Sans',
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Pilihan status kehadiran
              Positioned(
                top: 120,
                left: 30,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _radioButton('Hadir'),
                    _radioButton('Alpa'),
                    _radioButton('Izin / Sakit'),
                  ],
                ),
              ),

              // Tombol Simpan
              Positioned(
                bottom: 40,
                left: 25,
                child: GestureDetector(
                  onTap: _simpanAbsensi,
                  child: Container(
                    width: 190,
                    height: 45,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: const Center(
                      child: Text(
                        'SIMPAN',
                        style: TextStyle(
                          fontFamily: 'Open Sans',
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF53B7E8),
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _radioButton(String label) {
    return Row(
      children: [
        Radio<String>(
          value: label,
          groupValue: statusTerpilih,
          onChanged: (value) {
            setState(() {
              statusTerpilih = value;
            });
          },
          activeColor: Colors.white,
        ),
        Text(
          label,
          style: const TextStyle(color: Colors.white, fontSize: 14),
        ),
      ],
    );
  }
}