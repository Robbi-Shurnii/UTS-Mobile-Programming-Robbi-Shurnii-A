import 'package:flutter/material.dart';
import 'riwayat_jadwal.dart';

class DetailJadwalPage extends StatefulWidget {
  const DetailJadwalPage({super.key});

  @override
  State<DetailJadwalPage> createState() => _DetailJadwalPageState();
}

class _DetailJadwalPageState extends State<DetailJadwalPage> {
  DateTime? selectedDate;
  TimeOfDay? selectedTime;
  final TextEditingController kegiatanController = TextEditingController();

  Future<void> _pickDate(BuildContext context) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (pickedDate != null) {
      setState(() => selectedDate = pickedDate);
    }
  }

  Future<void> _pickTime(BuildContext context) async {
    final pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (pickedTime != null) {
      setState(() => selectedTime = pickedTime);
    }
  }

  void _simpanJadwal() {
    if (selectedDate != null &&
        selectedTime != null &&
        kegiatanController.text.isNotEmpty) {
      // Buat data jadwal yang disimpan
      final jadwal = {
        'tanggal':
            '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}',
        'waktu': selectedTime!.format(context),
        'kegiatan': kegiatanController.text,
      };

      // Pindah ke halaman riwayat sambil kirim data
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => RiwayatJadwalPage(jadwalBaru: jadwal),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Lengkapi semua data terlebih dahulu!'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),
              const Positioned(
                top: 30,
                left: 50,
                child: Text(
                  'Isi Jadwal',
                  style: TextStyle(
                    fontFamily: 'Open Sans',
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Pilih tanggal
              Positioned(
                top: 90,
                left: 8,
                child: GestureDetector(
                  onTap: () => _pickDate(context),
                  child: Container(
                    width: 200,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: Center(
                      child: Text(
                        selectedDate == null
                            ? 'Pilih Tanggal'
                            : '${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF53B7E8),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Pilih waktu
              Positioned(
                top: 150,
                left: 8,
                child: GestureDetector(
                  onTap: () => _pickTime(context),
                  child: Container(
                    width: 200,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: Center(
                      child: Text(
                        selectedTime == null
                            ? 'Pilih Waktu'
                            : selectedTime!.format(context),
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF53B7E8),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Nama kegiatan
              Positioned(
                top: 210,
                left: 8,
                child: Container(
                  width: 200,
                  height: 43,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7FCFF),
                    borderRadius: BorderRadius.circular(35),
                  ),
                  child: TextField(
                    controller: kegiatanController,
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Nama Kegiatan',
                      hintStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF53B7E8),
                        fontSize: 14,
                      ),
                    ),
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF53B7E8),
                      fontSize: 14,
                    ),
                  ),
                ),
              ),

              // Tombol simpan
              Positioned(
                bottom: 40,
                left: 8,
                child: GestureDetector(
                  onTap: _simpanJadwal,
                  child: Container(
                    width: 200,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0365A0),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: const Center(
                      child: Text(
                        'Simpan Jadwal',
                        style: TextStyle(
                          fontFamily: 'Open Sans',
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}