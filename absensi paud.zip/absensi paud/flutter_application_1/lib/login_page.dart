import 'package:flutter/material.dart';
import 'signup_page.dart';
import 'dashboard.dart'; // pastikan file ini ada

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    final usernameController = TextEditingController();
    final passwordController = TextEditingController();

    return Scaffold(
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            image: const DecorationImage(
              image: AssetImage('image/wallpaper.jpg'),
              fit: BoxFit.cover,
            ),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Bagian bawah (background biru)
              Positioned(
                top: 165,
                left: 0,
                child: Container(
                  width: 300,
                  height: 300,
                  decoration: BoxDecoration(
                    color: const Color(0xFF53B7E8),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(45),
                      topRight: Radius.circular(45),
                    ),
                    border: Border.all(color: Colors.white, width: 3),
                  ),
                ),
              ),

              // Tulisan "Login"
              const Positioned(
                top: 190,
                left: 85,
                child: Text(
                  'Login',
                  style: TextStyle(
                    fontFamily: 'Open Sans',
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.white,
                  ),
                ),
              ),

              // Label Username
              const Positioned(
                top: 240,
                left: 20,
                child: Text(
                  'Username',
                  style: TextStyle(
                    fontFamily: 'Open Sans',
                    fontSize: 12,
                    color: Colors.white,
                  ),
                ),
              ),

              // Label Password
              const Positioned(
                top: 275,
                left: 20,
                child: Text(
                  'Password',
                  style: TextStyle(
                    fontFamily: 'Open Sans',
                    fontSize: 12,
                    color: Colors.white,
                  ),
                ),
              ),

              // Input Username
              Positioned(
                top: 240,
                left: 90,
                child: Container(
                  width: 130,
                  height: 20,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TextField(
                    controller: usernameController,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      isDense: true,
                    ),
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ),

              // Input Password
              Positioned(
                top: 275,
                left: 90,
                child: Container(
                  width: 130,
                  height: 20,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      isDense: true,
                    ),
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ),

              // Tombol Login (klik → Dashboard)
              Positioned(
                top: 318,
                left: 22,
                child: SizedBox(
                  width: 180,
                  height: 30,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF53B7E8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50),
                        side: const BorderSide(color: Colors.white, width: 2),
                      ),
                    ),
                    onPressed: () {
                      // Navigasi ke dashboard
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const DashboardPage(),
                        ),
                      );
                    },
                    child: const Text(
                      'Login',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),

              // Garis “OR”
              const Positioned(
                top: 353,
                left: 100,
                child: Text(
                  'OR',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.white,
                    fontFamily: 'Open Sans',
                  ),
                ),
              ),

              // Tombol Login dengan Google
              Positioned(
                top: 370,
                left: 22,
                child: GestureDetector(
                  onTap: () {
                    // Aksi login Google
                  },
                  child: Container(
                    width: 180,
                    height: 30,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(50),
                      border: Border.all(color: Colors.white),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'image/google.jpg',
                          width: 18,
                          height: 18,
                        ),
                        const SizedBox(width: 6),
                        const Text(
                          'Login with Google',
                          style: TextStyle(
                            color: Color(0xFF53B7E8),
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // “Don’t have an account?”
              const Positioned(
                top: 410,
                left: 30,
                child: Text(
                  "Don't have an account?",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                  ),
                ),
              ),

              // “Sign Up” (bisa diklik)
              Positioned(
                top: 410,
                left: 147,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const SignupPage(),
                      ),
                    );
                  },
                  child: const Text(
                    'Sign Up',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
