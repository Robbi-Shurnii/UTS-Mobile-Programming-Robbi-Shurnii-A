import 'package:flutter/material.dart';
import 'tambah_siswa.dart';
import 'hadir_alpa_izin_sakit.dart';

class DaftarSiswaPage extends StatefulWidget {
  const DaftarSiswaPage({super.key});

  @override
  State<DaftarSiswaPage> createState() => _DaftarSiswaPageState();
}

class _DaftarSiswaPageState extends State<DaftarSiswaPage> {
  List<Map<String, dynamic>> daftarSiswa = [];

  // Fungsi untuk pindah ke halaman tambah siswa
  Future<void> tambahSiswaBaru() async {
    final hasil = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const TambahSiswaPage()),
    );

    if (hasil != null && mounted) {
      setState(() {
        daftarSiswa.add(hasil);
      });
    }
  }

  // Fungsi untuk ke halaman detail absensi siswa
  void bukaDetailSiswa(String nama) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HadirAlpaIzinSakitPage(namaSiswa: nama),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF53b7e8),
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53b7e8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [
              BoxShadow(
                color: Colors.black45,
                blurRadius: 12,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                  child: const Center(
                    child: Text(
                      "Daftar Siswa",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ),
              ),

              // Daftar nama siswa
              Positioned(
                top: 80,
                left: 20,
                right: 20,
                bottom: 70,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: ListView.builder(
                    itemCount: daftarSiswa.length,
                    itemBuilder: (context, index) {
                      final siswa = daftarSiswa[index];
                      return ListTile(
                        leading: const Icon(Icons.person, color: Colors.white),
                        title: Text(
                          siswa['nama'],
                          style: const TextStyle(color: Colors.white),
                        ),
                        onTap: () => bukaDetailSiswa(siswa['nama']),
                      );
                    },
                  ),
                ),
              ),

              // Tombol tambah siswa
              Positioned(
                bottom: 20,
                left: 20,
                right: 20,
                child: GestureDetector(
                  onTap: tambahSiswaBaru,
                  child: Container(
                    height: 35,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: const Center(
                      child: Text(
                        "TAMBAH SISWA",
                        style: TextStyle(
                          color: Color(0xFF53b7e8),
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}