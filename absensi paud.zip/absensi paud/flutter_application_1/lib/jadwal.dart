import 'package:flutter/material.dart';
import 'detail_jadwal.dart';

class JadwalPage extends StatelessWidget {
  const JadwalPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black12,
      body: Center(
        child: Container(
          width: 240,
          height: 480,
          decoration: BoxDecoration(
            color: const Color(0xFF53B7E8),
            border: Border.all(color: Colors.black, width: 12),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 12,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Header
              Positioned(
                top: 10,
                left: 8,
                child: Container(
                  width: 200,
                  height: 57,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0365A0),
                    borderRadius: BorderRadius.circular(35),
                  ),
                ),
              ),

              const Positioned(
                top: 30,
                left: 36,
                child: Text(
                  'Jadwal Kegiatan',
                  style: TextStyle(
                    fontFamily: 'Open Sans',
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 14,
                  ),
                ),
              ),

              // Tombol menuju form isi jadwal
              Positioned(
                top: 83,
                left: 8,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const DetailJadwalPage(),
                      ),
                    );
                  },
                  child: Container(
                    width: 200,
                    height: 43,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7FCFF),
                      borderRadius: BorderRadius.circular(35),
                    ),
                    child: const Center(
                      child: Text(
                        'Tambah Jadwal',
                        style: TextStyle(
                          fontFamily: 'Open Sans',
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF53B7E8),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}